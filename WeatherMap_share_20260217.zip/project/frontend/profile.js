// Precipitation rendering for Tour Profile panel
// Functions: drawRainProbabilityArea(ctx, points, opts), drawRainBars(ctx, points, opts)
// points: [{ dist, rainProb, rainTypical }], sorted by dist ascending
// opts: { padTop, padBot, padL, padR, innerW, innerH, xAt }

(function(){
  function clamp01(v){ return Math.max(0, Math.min(1, Number(v))); }

  function drawRainProbabilityArea(ctx, points, opts){
    if (!ctx || !points || points.length < 2) return;
    const { padTop, padBot, padL, padR, innerW, innerH, xAt } = opts;
    const maxPx = 30; // 0..30 px
    // Build path upper boundary by prob height above bottom
    ctx.beginPath();
    for (let i = 0; i < points.length; i++) {
      const p = points[i];
      const prob = clamp01(p.rainProb);
      const h = prob * maxPx;
      const x = xAt(p.dist);
      const y = padTop + innerH - h;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    // Close against bottom baseline
    ctx.lineTo(padL + innerW, padTop + innerH);
    ctx.lineTo(padL, padTop + innerH);
    ctx.closePath();
    ctx.fillStyle = 'rgba(100, 180, 255, 0.20)'; // light blue, opacity 0.2
    ctx.fill();
  }

  function drawRainBars(ctx, points, opts){
    if (!ctx || !points || points.length === 0) return;
    const { padTop, padBot, padL, padR, innerW, innerH, xAt } = opts;
    const maxMm = 25.0;          // stretch to full chart height
    const pxPerMm = innerH / maxMm;
    const barW = 12;             // widened by 300%
    for (let i = 0; i < points.length; i++) {
      const p = points[i];
      const mm = Number(p.rainTypical);
      if (!Number.isFinite(mm)) continue;
      const mmCap = Math.max(0, Math.min(maxMm, mm));
      const h = mmCap * pxPerMm;
      const x = xAt(p.dist);
      const y = padTop + innerH - h;
      const alpha = 0.6 + 0.3 * clamp01(p.rainProb); // 0.6–0.9 by probability
      ctx.fillStyle = `rgba(30, 112, 200, ${alpha.toFixed(3)})`;
      ctx.fillRect(Math.round(x - barW/2), Math.round(y), barW, Math.round(h));
    }
    // Removed: horizontal grid lines for a cleaner precipitation diagram
  }

  // Export to window
  window.drawRainProbabilityArea = drawRainProbabilityArea;
  window.drawRainBars = drawRainBars;

  // ---------------- Wind Profile ----------------
  // points: [{ dist, windSpeed, windDir, windVar }], sorted by dist
  // profile: { sampled_dist_km: [], sampled_heading_deg: [] }
  function computeEffectiveWind(points, profile) {
    if (!Array.isArray(points) || points.length < 2) return null;
    const dist = Array.isArray(profile?.sampled_dist_km) ? profile.sampled_dist_km : [];
    const headings = Array.isArray(profile?.sampled_heading_deg) ? profile.sampled_heading_deg : [];
    if (!dist.length || dist.length !== headings.length) return null;
    // Binary search nearest profile index by distance
    const nearestIdx = (d) => {
      let lo = 0, hi = dist.length - 1;
      while (lo < hi) {
        const mid = (lo + hi) >> 1;
        if (dist[mid] < d) lo = mid + 1; else hi = mid;
      }
      return lo;
    };
    const rad = (deg) => (Number(deg) * Math.PI / 180.0);
    const out = points.map(p => {
      const i = nearestIdx(Number(p.dist));
      const routeDir = Number(headings[i] ?? 0);
      const wsp = Number(p.windSpeed);
      const wdir = Number(p.windDir);
      if (!Number.isFinite(wsp) || !Number.isFinite(wdir)) {
        return { dist: Number(p.dist), eff: null, varDeg: Number(p.windVar) };
      }
      const ang = rad(wdir - routeDir);
      const eff = wsp * Math.cos(ang);
      return { dist: Number(p.dist), eff, varDeg: Number(p.windVar) };
    }).filter(x => Number.isFinite(x.dist));
    return out;
  }

  function drawWindProfile(ctx, data, opts) {
    if (!ctx || !Array.isArray(data) || data.length < 2) return;
    const { padTop, padBot, padL, padR, innerW, innerH, xAt } = opts;
    // Axis: -8..+8 m/s
    const ymin = -8.0, ymax = 8.0;
    const yAt = (v) => {
      const vv = Math.max(ymin, Math.min(ymax, Number(v)));
      const u = (vv - ymin) / Math.max(1e-6, (ymax - ymin));
      return padTop + innerH - Math.round(innerH * u);
    };
    // Variability band: map varDeg (0..60) to ±bandMs
    const bandMsFor = (varDeg) => {
      const vd = Math.max(0, Math.min(60, Number(varDeg || 0)));
      return (vd / 60.0) * 2.0; // up to ±2 m/s at 60°
    };
    // Build upper/lower paths for band
    const valid = data.filter(d => Number.isFinite(d.eff));
    if (valid.length < 2) return;
    // Grid lines removed for cleaner wind visualization
    // Band polygon
    ctx.beginPath();
    for (let i = 0; i < valid.length; i++) {
      const d = valid[i];
      const x = xAt(d.dist);
      const yU = yAt(d.eff + bandMsFor(d.varDeg));
      if (i === 0) ctx.moveTo(x, yU); else ctx.lineTo(x, yU);
    }
    for (let i = valid.length - 1; i >= 0; i--) {
      const d = valid[i];
      const x = xAt(d.dist);
      const yL = yAt(d.eff - bandMsFor(d.varDeg));
      ctx.lineTo(x, yL);
    }
    ctx.closePath();
    ctx.fillStyle = 'rgba(80,80,80,0.15)';
    ctx.fill();
    // Line colored by sign and magnitude (rounded caps/joins)
    ctx.lineWidth = 2;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.setLineDash([]);
    // Stroke in segments; if sign changes, split at zero crossing and switch color
    const eps = 0.05; // near-zero threshold
    function colorForEff(eff){
      const m = Math.min(1, Math.max(0, Math.abs(eff) / 8.0));
      if (eff > eps) return `rgba(60,180,90,${0.6 + 0.4*m})`; // tailwind: green
      if (eff < -eps) return `rgba(220,80,60,${0.6 + 0.4*m})`;  // headwind: red
      return 'rgba(120,120,120,0.6)'; // near zero: gray
    }
    ctx.lineWidth = 2;
    for (let i = 1; i < valid.length; i++) {
      const d0 = valid[i-1], d1 = valid[i];
      const e0 = Number(d0.eff), e1 = Number(d1.eff);
      const x0 = xAt(d0.dist), y0 = yAt(e0);
      const x1 = xAt(d1.dist), y1 = yAt(e1);
      const s0 = e0 > eps ? 1 : (e0 < -eps ? -1 : 0);
      const s1 = e1 > eps ? 1 : (e1 < -eps ? -1 : 0);
      if (s0 !== 0 && s1 !== 0 && s0 !== s1) {
        // Zero crossing within segment: linear interpolation to eff=0
        const denom = (e1 - e0);
        const t = denom !== 0 ? Math.max(0, Math.min(1, (-e0) / denom)) : 0.5;
        const xz = x0 + (x1 - x0) * t;
        const yz = yAt(0);
        // First sub-segment: x0,y0 -> xz,yz in color of e0
        ctx.strokeStyle = colorForEff(e0);
        ctx.beginPath();
        ctx.moveTo(x0, y0);
        ctx.lineTo(xz, yz);
        ctx.stroke();
        // Second sub-segment: xz,yz -> x1,y1 in color of e1
        ctx.strokeStyle = colorForEff(e1);
        ctx.beginPath();
        ctx.moveTo(xz, yz);
        ctx.lineTo(x1, y1);
        ctx.stroke();
      } else {
        // No sign change: single stroke with color for target eff
        ctx.strokeStyle = colorForEff(e1);
        ctx.beginPath();
        ctx.moveTo(x0, y0);
        ctx.lineTo(x1, y1);
        ctx.stroke();
      }
    }
    // Right-side axis ticks and label for readability
    ctx.strokeStyle = '#666';
    ctx.fillStyle = '#666';
    ctx.lineWidth = 1;
    ctx.font = '10px system-ui, -apple-system, sans-serif';
    ctx.textAlign = 'right';
    const ticks = [-6, -3, 0, 3, 6];
    const xScale = padL + innerW - 8; // slightly inside the chart
    const tickLen = 6;
    for (const tv of ticks) {
      const y = yAt(tv);
      ctx.beginPath();
      ctx.moveTo(xScale - tickLen, y);
      ctx.lineTo(xScale, y);
      ctx.stroke();
      ctx.fillText(`${tv} m/s`, xScale - 4, y + 3);
    }
    // Axis label at top-right
    ctx.fillText('Effective wind (m/s)', xScale - 4, padTop + 12);
    // Legend: label the blue and red sample lines
    try {
      const lx = xScale - 120; // legend left x
      const ly1 = padTop + 26;
      const ly2 = padTop + 40;
      ctx.lineWidth = 3;
      // Tailwind sample line (green) + label
      ctx.strokeStyle = 'rgba(60,180,90,1)';
      ctx.beginPath();
      ctx.moveTo(lx, ly1);
      ctx.lineTo(lx + 28, ly1);
      ctx.stroke();
      ctx.fillStyle = '#333';
      ctx.font = '10px system-ui, -apple-system, sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText('Tailwind', lx + 34, ly1 + 3);
      // Headwind sample line (red) + label
      ctx.strokeStyle = 'rgba(220,80,60,1)';
      ctx.beginPath();
      ctx.moveTo(lx, ly2);
      ctx.lineTo(lx + 28, ly2);
      ctx.stroke();
      ctx.fillStyle = '#333';
      ctx.fillText('Headwind', lx + 34, ly2 + 3);
    } catch(_) {}
  }

  window.computeEffectiveWind = computeEffectiveWind;
  window.drawWindProfile = drawWindProfile;
})();
